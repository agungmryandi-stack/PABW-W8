<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Buku\\Providers\\BukuServiceProvider',
    1 => 'Modules\\Peminjaman\\Providers\\PeminjamanServiceProvider',
    2 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Buku\\Providers\\BukuServiceProvider',
    1 => 'Modules\\Peminjaman\\Providers\\PeminjamanServiceProvider',
    2 => 'Modules\\UserManagement\\Providers\\UserManagementServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);