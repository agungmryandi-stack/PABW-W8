<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <?php echo $__env->make('layouts.partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>

<body>
    <nav class="navbar navbar-expand-lg bg-white border-bottom py-2">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center gap-2 fw-semibold" href="<?php echo e(route('dashboard')); ?>">
                <span class="logo"><i class="bi bi-book-half"></i></span>
                <?php echo e(config('app.name', 'Laravel')); ?>

            </a>

            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse"
                data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false"
                aria-label="Buka menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav me-auto ms-lg-4 gap-lg-1">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"
                            href="<?php echo e(route('dashboard')); ?>">
                            <i class="bi bi-house me-1"></i> Dashboard
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('buku.*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('buku.index')); ?>">
                            <i class="bi bi-book me-1"></i> Buku
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('peminjaman.*') ? 'active' : ''); ?>"
                            href="<?php echo e(route('peminjaman.index')); ?>">
                            <i class="bi bi-journal-check me-1"></i> Peminjaman
                        </a>
                    </li>

                    <?php if(auth()->user()->isAdmin()): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('admin.users.index')); ?>">
                                <i class="bi bi-people me-1"></i> Kelola User
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>

                <div class="dropdown">
                    <button class="btn btn-light dropdown-toggle d-flex align-items-center gap-2" type="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-person-circle"></i>
                        <span><?php echo e(auth()->user()->name); ?></span>
                    </button>

                    <ul class="dropdown-menu dropdown-menu-end">
                        <li class="px-3 py-2 small">
                            <div class="text-muted"><?php echo e(auth()->user()->email); ?></div>
                            <span class="badge <?php echo e(auth()->user()->isAdmin() ? 'text-bg-primary' : 'text-bg-secondary'); ?> mt-1">
                                <?php echo e(auth()->user()->role->label()); ?>

                            </span>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <main class="container py-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible alert-autohide fade show d-flex align-items-center gap-2"
                role="alert">
                <i class="bi bi-check-circle"></i>
                <span><?php echo e(session('success')); ?></span>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2" role="alert">
                <i class="bi bi-exclamation-triangle"></i>
                <span><?php echo e(session('error')); ?></span>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php echo $__env->make('layouts.partials.scripts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W8\TugasAkhir\sipustaka_hmvc\resources\views/layouts/app.blade.php ENDPATH**/ ?>