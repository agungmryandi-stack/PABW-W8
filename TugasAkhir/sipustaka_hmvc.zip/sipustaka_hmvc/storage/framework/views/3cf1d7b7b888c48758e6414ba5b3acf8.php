<?php $__env->startSection('title', 'Tambah Buku'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-lg-7">
            <a href="<?php echo e(route('buku.index')); ?>" class="text-decoration-none small">
                <i class="bi bi-arrow-left"></i> Kembali ke daftar buku
            </a>
            <h4 class="mt-2 mb-4">Tambah Buku</h4>

            <div class="card">
                <div class="card-body p-4">
                    <form action="<?php echo e(route('buku.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <?php echo $__env->make('buku::partials.form', ['buku' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="d-flex justify-content-end gap-2">
                            <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-light">Batal</a>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W8\TugasAkhir\sipustaka_hmvc\Modules/Buku\resources/views/create.blade.php ENDPATH**/ ?>