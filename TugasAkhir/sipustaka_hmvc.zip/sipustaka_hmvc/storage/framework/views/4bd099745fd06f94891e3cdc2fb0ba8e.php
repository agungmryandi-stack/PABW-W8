<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <h4 class="mb-1">Halo, <?php echo e(auth()->user()->name); ?></h4>
        <p class="text-muted mb-0">
            Anda login sebagai <strong><?php echo e(auth()->user()->role->label()); ?></strong>.
            Pilih menu di bawah untuk mulai bekerja.
        </p>
    </div>

    <div class="row g-3">
        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="icon-box blue"><i class="bi bi-book"></i></span>
                    <div class="flex-grow-1">
                        <div class="text-muted small">Total Buku</div>
                        <div class="fs-4 fw-semibold"><?php echo e($totalBuku); ?></div>
                    </div>
                </div>
                <div class="card-footer bg-white border-top-0 pt-0">
                    <a href="<?php echo e(route('buku.index')); ?>" class="small text-decoration-none">
                        Lihat data buku <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-lg-4">
            <div class="card h-100">
                <div class="card-body d-flex align-items-center gap-3">
                    <span class="icon-box green"><i class="bi bi-journal-check"></i></span>
                    <div class="flex-grow-1">
                        <div class="text-muted small">Total Peminjaman</div>
                        <div class="fs-4 fw-semibold"><?php echo e($totalPeminjaman); ?></div>
                    </div>
                </div>
                <div class="card-footer bg-white border-top-0 pt-0">
                    <a href="<?php echo e(route('peminjaman.index')); ?>" class="small text-decoration-none">
                        Kelola peminjaman <i class="bi bi-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

        <?php if(auth()->user()->isAdmin()): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100">
                    <div class="card-body d-flex align-items-center gap-3">
                        <span class="icon-box gray"><i class="bi bi-people"></i></span>
                        <div class="flex-grow-1">
                            <div class="text-muted small">Total User</div>
                            <div class="fs-4 fw-semibold"><?php echo e($totalUsers); ?></div>
                        </div>
                    </div>
                    <div class="card-footer bg-white border-top-0 pt-0">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="small text-decoration-none">
                            Kelola User <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W8\TugasAkhir\sipustaka_hmvc\resources\views/dashboard.blade.php ENDPATH**/ ?>