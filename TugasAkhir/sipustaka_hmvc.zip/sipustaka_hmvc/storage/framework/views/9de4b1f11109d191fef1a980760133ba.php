<?php $__env->startSection('title', 'Data Buku'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h4 class="mb-1">Data Buku</h4>
            <p class="text-muted mb-0 small">
                <?php echo e(auth()->user()->isAdmin() ? 'Tambah, ubah, dan hapus koleksi buku perpustakaan.' : 'Daftar koleksi buku perpustakaan.'); ?>

            </p>
        </div>

        <?php if(auth()->user()->isAdmin()): ?>
            <a href="<?php echo e(route('buku.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-lg me-1"></i> Tambah Buku
            </a>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-header py-3">
            <form method="GET" action="<?php echo e(route('buku.index')); ?>" class="row g-2 align-items-center">
                <div class="col-sm-8 col-lg-5">
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                        <input type="search" name="search" value="<?php echo e($search); ?>"
                            class="form-control border-start-0" placeholder="Cari judul, penulis, atau penerbit...">
                    </div>
                </div>

                <div class="col-auto">
                    <button type="submit" class="btn btn-light border">Cari</button>
                    <?php if($search !== ''): ?>
                        <a href="<?php echo e(route('buku.index')); ?>" class="btn btn-link text-decoration-none">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Judul</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun</th>
                        <th>Stok</th>
                        <?php if(auth()->user()->isAdmin()): ?>
                            <th class="text-end">Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted"><?php echo e($bukus->firstItem() + $loop->index); ?></td>
                            <td class="fw-medium"><?php echo e($buku->judul); ?></td>
                            <td><?php echo e($buku->penulis); ?></td>
                            <td><?php echo e($buku->penerbit); ?></td>
                            <td><?php echo e($buku->tahun_terbit); ?></td>
                            <td>
                                <span class="badge <?php echo e($buku->stok > 0 ? 'text-bg-success' : 'text-bg-danger'); ?>">
                                    <?php echo e($buku->stok); ?>

                                </span>
                            </td>

                            <?php if(auth()->user()->isAdmin()): ?>
                                <td class="text-end text-nowrap">
                                    <a href="<?php echo e(route('buku.edit', $buku)); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i> Edit
                                    </a>

                                    <form action="<?php echo e(route('buku.destroy', $buku)); ?>" method="POST" class="d-inline"
                                        data-confirm="Buku &quot;<?php echo e($buku->judul); ?>&quot; akan dihapus dan tidak bisa dikembalikan.">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(auth()->user()->isAdmin() ? 7 : 6); ?>">
                                <div class="empty-state">
                                    <i class="bi bi-book"></i>
                                    <p class="mt-2 mb-0">Belum ada buku yang cocok dengan pencarian.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($bukus->hasPages()): ?>
            <div class="card-footer bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
                <small class="text-muted">
                    Menampilkan <?php echo e($bukus->firstItem()); ?>-<?php echo e($bukus->lastItem()); ?> dari <?php echo e($bukus->total()); ?> buku
                </small>
                <?php echo e($bukus->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W8\TugasAkhir\sipustaka_hmvc\Modules/Buku\resources/views/index.blade.php ENDPATH**/ ?>