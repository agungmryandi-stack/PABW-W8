<?php $__env->startSection('title', 'Kelola User'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
        <div>
            <h4 class="mb-1">Kelola User</h4>
            <p class="text-muted mb-0 small">Tambah, ubah, dan hapus akun pengguna aplikasi.</p>
        </div>
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
            <i class="bi bi-person-plus me-1"></i> Tambah User
        </a>
    </div>

    <div class="card">
        <div class="card-header py-3">
            <form method="GET" action="<?php echo e(route('admin.users.index')); ?>" class="row g-2 align-items-center">
                <div class="col-sm-6 col-lg-4">
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                        <input type="search" name="search" value="<?php echo e($search); ?>"
                            class="form-control border-start-0" placeholder="Cari nama atau email...">
                    </div>
                </div>

                <div class="col-sm-3 col-lg-2">
                    <select name="role" class="form-select" onchange="this.form.submit()" aria-label="Filter role">
                        <option value="">Semua role</option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($role->value); ?>" <?php if($selectedRole === $role): echo 'selected'; endif; ?>>
                                <?php echo e($role->label()); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-auto">
                    <button type="submit" class="btn btn-light border">Cari</button>
                    <?php if($search !== '' || $selectedRole): ?>
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-link text-decoration-none">Reset</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th class="text-end">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php ($isCurrentUser = $user->is(auth()->user())); ?>
                        <tr>
                            <td class="text-muted"><?php echo e($users->firstItem() + $loop->index); ?></td>
                            <td class="fw-medium">
                                <?php echo e($user->name); ?>

                                <?php if($isCurrentUser): ?>
                                    <span class="badge text-bg-light border ms-1">Anda</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->email); ?></td>
                            <td>
                                <span class="badge <?php echo e($user->isAdmin() ? 'text-bg-primary' : 'text-bg-secondary'); ?>">
                                    <?php echo e($user->role->label()); ?>

                                </span>
                            </td>
                            <td class="text-end text-nowrap">
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>

                                <?php if (! ($isCurrentUser)): ?>
                                    <form action="<?php echo e(route('admin.users.destroy', $user)); ?>" method="POST"
                                        class="d-inline"
                                        data-confirm="Akun &quot;<?php echo e($user->name); ?>&quot; akan dihapus dan tidak bisa dikembalikan.">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5">
                                <div class="empty-state">
                                    <i class="bi bi-person-x"></i>
                                    <p class="mt-2 mb-0">Tidak ada user yang cocok dengan pencarian.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($users->hasPages()): ?>
            <div class="card-footer bg-white d-flex flex-wrap justify-content-between align-items-center gap-2">
                <small class="text-muted">
                    Menampilkan <?php echo e($users->firstItem()); ?>-<?php echo e($users->lastItem()); ?> dari <?php echo e($users->total()); ?> user
                </small>
                <?php echo e($users->links('pagination::bootstrap-5')); ?>

            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\Praktikum\W8\TugasAkhir\sipustaka_hmvc\Modules/UserManagement\resources/views/index.blade.php ENDPATH**/ ?>