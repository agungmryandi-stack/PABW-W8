<?php

return [
    'name' => 'Peminjaman',
];
